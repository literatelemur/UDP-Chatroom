This is a UDP chat application 
by Luke Carrington

No special modules are required to run it; it is all native to the latest version of Python. Simply open up the Display.py file alognside Device.py and run it to get going. 

A few things to note about the software:

1) The server-side initiation (clicking "start" when prompted) freezes while waiting for client communication. This condition resolves as soon as client contact is made.

2) The progress bar for file transfer seems to visually behave strangely, as the right edge creeps away from the progress bar itself. This condition is a result of using text to mark progress: it is not a miscalculation of progress, only a misrepresentation due to "-" taking up more room than " ".

3) File downloaded are put in the local directory for the program. They all exist alongside the .py files themselves.

4) Emojis are treated as photos and are therefore placed in the local directory as well. They can unsurprisingly be found in the "emojis" folder, and as long as they remain in that folder, they should function within the program.

5) Similarly to the past two points, the chat log is stored locally. Deleting it will simply instruct the program to create a new file of the same name next session. The log can of course be viewed by itself, but it is intended to be seen in the program.

6) The SYNFLOOD .py file is a penetration testing script. It was more simple to construct than anticipated, but it is run by first running the Display.py file as a server (clicking "start") and then running the SYNFLOOD script inputting the IP address of the server. Then watch as resources are tied up and the server application freezes. It is truly a DDoS attack.

That's about all.