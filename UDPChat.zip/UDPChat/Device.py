import json
from socket import *
import random
import sys
from threading import Thread
import datetime
import time
from struct import *


class Device:

    def __init__(self, address=None, port=None, expec_seq=None):

        # Instance for the user
        if address is None and port is None and expec_seq is None:
            self.sock = socket(AF_INET, SOCK_DGRAM)
            self.address = gethostbyname(gethostname())
            # Port is unknown at this time since port designation is dependent upon the user being a client or server
            self.port = None
            self.others = []
            self.history = []

            self.seq = random.randint(0, 4294967295)
            self.chat_log_time = None
            self.chat_log_users = None

            self.first_shake = True
            self.excep = False

            self.base = self.seq
            self.retran_cache = []
            self.kill_retran = False
            self.running_timer = False

            self.drop=0

        # Instances for 'others' list in user instance to record all other participating parties' needed information
        elif address is not None and port is not None and expec_seq is not None:
            self.address = address
            self.port = port
            self.history = []
            self.expec_seq = expec_seq

    def server_handshake(self):
        if self.first_shake:
            # Create and setup a UDP socket with port number 22000
            self.port = 22000
            self.sock.bind(('', self.port))
            self.first_shake = False

        # Receiving/sending handshake messages to initiate connection with server
        got_header, got_message, got_address_port, owner, seq_dif = self.recv()
        header = [self.seq, self.others[0].expec_seq, 1, 0, 0, self.others.__len__()]
        send_message = ''
        self.send(header, send_message)
        self.sock.settimeout(3)
        got_header, got_message, got_address_port, owner, seq_dif = self.recv()
        if not isinstance(got_header, bool):
            if got_address_port[0] == self.others[self.others.__len__()-1].address and got_address_port[1] == self.others[self.others.__len__()-1].port and got_header[1] == self.seq:
                self.chat_log_time = datetime.datetime.now()
                self.chat_log_users = '1 other person is in this chat'
                return got_address_port[0] + ' has entered the chat.'
        else:
            if not got_header:
                del(self.others[self.others.__len__()-1])
                self.kill_retran = True
                self.sock.settimeout(None)
                self.server_handshake()

    def client_handshake(self, address):
        self.drop = -99999
        # The server is regarded as the first Device object added to the 'others' list denoting involved parties
        self.others.append(Device(address, 22000, -1))

        # Sending/receiving handshake messages to initiate connection with server
        header = [self.seq, None, 1, 0, 0, None]
        send_message = ''
        self.send(header, send_message)
        self.kill_retran = True
        while True:
            got_header, got_message, got_address_port, owner, seq_dif = self.recv()
            if got_header[2] == 1 and got_address_port[0] == self.others[0].address and got_address_port[1] == self.others[0].port:
                header = [None, self.others[0].expec_seq, 0, 0, 0, None]
                send_message = ''
                self.send(header, send_message)
                self.chat_log_time = datetime.datetime.now()
                if got_header[5] == 1:
                    message = 'You are connected. There is 1 other person in this chat.'
                    self.chat_log_users = str(got_header[5]) + ' other person is in this chat'
                    break
                else:
                    message = 'You are connected. There are', got_header[5], 'other people in this chat.'
                    self.chat_log_users = str(got_header[5]) + ' other people are in this chat'
                    break
        return message

    def recv(self):
        try:
            got_message, got_address_port = self.sock.recvfrom(1024)
        except Exception:
            return False, False, False, False, False

        # self.drop+=1
        # if not (3<self.drop<6):
        got_message = got_message.decode()
        got_header = json.loads(got_message[0: got_message.find(']') + 1])
        got_message = got_message[got_message.find(']') + 1: got_message.__len__()]

        owner = ''
        for i in range(0, self.others.__len__()):
            if got_address_port[0] == self.others[i].address and got_address_port[1] == self.others[i].port:
                owner = self.others[i]
        if owner == '':
            expec_seq = got_header[0]
            self.others.append(Device(got_address_port[0], got_address_port[1], expec_seq))
            owner = self.others[self.others.__len__() - 1]

        elif owner.expec_seq == -1:
            owner.expec_seq = got_header[0]

        seq_dif = 1
        # Checking ACK field
        if got_header[1] is not None:
            # Stop timer and update base when ACK received corresponds to current base
            if got_header[1] > self.base:
                # if got_header[4] == -2:
                #     seq_dif = got_header[1] - 1 - (self.base - 1)
                self.base = got_header[1]
                #self.kill_retran = True
                last_length = self.retran_cache.__len__()
                i = 0
                while True:
                    if i <= self.retran_cache.__len__() - 1 and self.retran_cache.__len__() > 0:
                        full_message = self.retran_cache[0]
                        header = json.loads(full_message[0: full_message.find(']') + 1])
                        if header[0] < self.base:
                            del self.retran_cache[0]
                    if last_length == self.retran_cache.__len__():
                        i = i + 1
                    else:
                        dif = self.retran_cache.__len__() - last_length
                        i = i + dif
                    if i <= self.retran_cache.__len__() - 1 and self.retran_cache.__len__() > 0:
                        last_length = self.retran_cache.__len__()
                    else:
                        break
                if self.retran_cache.__len__() == 0:
                    self.kill_retran = True

        # Remove record of other user and stop timer when other user leaves
        if got_header[3] == 1:
            self.others.remove(owner)
            self.kill_retran = True

        # Checking received sequence number with that Device's expec_seq to ensure that the correct in-order packet has been received.
        # If not, the packet is dropped with False being returned to signal for recv_message_mode to not proceed
        # ACK packets are included as got_header[0] is None (no sequence number with an ACK field) since they are
        # standard functioning and should be passed to recv_message_mode for processing too
        if got_header[0] == owner.expec_seq:
            owner.expec_seq = self.update_seq(owner.expec_seq)
            return got_header, got_message, got_address_port, owner, seq_dif
        elif got_header[0] is None and got_header[1] is not None:
            return got_header, got_message, got_address_port, owner, seq_dif
        else:
            return True, True, True, True, True
        # else:
        #     return False, False, False, False, False

    def send(self, header, send_message, utf=None):
        send_message = json.dumps(header) + send_message
        # Send message to every member of the chat room (with multi user chats not being fully implemented elsewhere)
        for i in range(0, self.others.__len__()):
            self.sock.sendto(send_message.encode(), (self.others[i].address, self.others[i].port))
        # Add message to retransmission list when standard content message (with seq number and therefore not an ACK [excluding the server handshake ACK since it is a special case])
        if header[0] is not None:
            if self.retran_cache.__contains__('[]'):
                self.retran_cache.remove('[]')
                self.retran_cache.append(send_message)
                self.retran_cache.append('[]')
            else:
                self.retran_cache.append(send_message)

            # Start Thread to wait for ACK and retransmit if needed
            if self.retran_cache.__len__() > 0:
                Thread(target=self.timeout, daemon=True).start()

            self.update_seq()

    def file_transfer(self, file_path, file_name, file_size):
        # Format and send initial file transfer message containing header[4] signal of file transfer start and a second header for file name and file size
        header = [self.seq, None, 0, 0, 1, None]
        head_file_name_size = '[' + file_name + ',' + str(file_size) + ']'
        hist_message = 'Sending file: ' + file_name
        send_message = head_file_name_size + hist_message
        self.send(header, send_message)
        self.update_history(self, hist_message)
        # Iterate through the bits in file sending chunks of data no larger than 1024 bytes until nothing is found (file ends)
        with open(file_path, 'rb') as file:
            file_chunk = ''
            utf = True
            while True:
                piece = file.read(1)
                try:
                    piece = piece.decode()
                except (UnicodeDecodeError, AttributeError):
                    utf = False
                if not piece:
                    break
                if utf:
                    file_chunk = file_chunk + piece
                else:
                    file_chunk = file_chunk + ",".join(unpack('hh1' + piece))
                if sys.getsizeof(file_chunk) > 1023:
                    header = [self.seq, None, 0, 0, 2, utf]
                    time.sleep(0.01)
                    self.send(header, file_chunk, utf)
                    file_chunk = ''
            # When StopIteration is raised (nothing left in file), a final message is sent containing any final file data and a header[4] value indicating the last file transfer message in the stream
            header = [self.seq, None, 0, 0, 3, utf]
            self.send(header, file_chunk, utf)
            self.update_history(self, '', 3, file_name)

    def timeout(self):
        # Wait one second for ACK to be received. Afterwards a variable is checked that is set Trus when the correct
        # ACK is received so that the timeout thread can terminate without unnecessary retransmissions. If not yet
        # received, all messages containing content are sent to all users again. This repeats until the correct ACK is received.
        if self.running_timer is False:
            self.running_timer = True
            while True:
                time.sleep(1)
                if self.kill_retran:
                    self.kill_retran = False
                    self.running_timer = False
                    break
                i = 0
                last_length = self.retran_cache.__len__()
                while True:
                    for y in self.others:
                        if i <= self.retran_cache.__len__() - 1:
                            self.sock.sendto(self.retran_cache[i].encode(), (y.address, y.port))
                        else:
                            break
                    if last_length == self.retran_cache.__len__():
                        i = i + 1
                    else:
                        dif = self.retran_cache.__len__() - last_length
                        i = i + dif
                    if i <= self.retran_cache.__len__() - 1:
                        last_length = self.retran_cache.__len__()
                    else:
                        break


    def update_history(self, owner, message, transfer_header=None, file_name=None):
        # Iterate through self.others list adding nothing when they are not the owner of a message and the message when
        # they are so that all separate history lists attached to each user line up in a vertical representation of time
        # for a unified display of messages presented in chronological order with owner information known for each message

        if owner == self:
            for i in range(0, self.others.__len__()):
                self.others[i].history.append('')
        else:
            for i in range(0, self.others.__len__()):
                if owner != self.others[i]:
                    self.others[i].history.append('')
        if transfer_header is None and file_name is None:
            if owner != self:
                self.history.append('')
            owner.history.append(message)
        else:
            # For each transfer header signal in header[4] (1 = start, 2 = middle, 3= end), an appropriate action is
            # taken so that a single message is shown in display (represented in history) for a file and that message
            # is found and edited upon completion of downloading/sending a file
            if transfer_header == 1:
                owner.history.append('Downloading file: ' + file_name)
                self.history.append('')
            elif transfer_header == 3:
                if owner == self:
                    for i in range(self.history.__len__() - 1, -1, -1):
                        if self.history[i] == 'Sending file: ' + file_name:
                            self.history.remove('Sending file: ' + file_name)
                            self.history.insert(i, 'File sent: ' + file_name)
                else:
                    for i in range(owner.history.__len__() - 1, -1, -1):
                        if owner.history[i] == 'Downloading file: ' + file_name:
                            owner.history.remove('Downloading file: ' + file_name)
                            owner.history.insert(i, 'File downloaded: ' + file_name)
        
    def update_seq(self, expec_seq=None, file_name=None):
        #Simple (if not messy since code is almost repeated) method to update sequence number. It exists purely for the
        # case in which the sequence number exceeds the 32-bit limit and must be wrapped around to zero.
        if expec_seq is None:
            if self.seq == 4294967295:
                self.seq = 0
            else:
                self.seq += 1
        else:
            if expec_seq == 4294967295:
                expec_seq = 0
            else:
                expec_seq += 1
            return expec_seq
