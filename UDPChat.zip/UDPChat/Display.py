import Device
from tkinter import *
from threading import Thread
import atexit
import os
import queue
from struct import *
from pathlib import Path


recv_message_queue = queue.Queue()
recv_event = '<<recv>>'
block_event = False
send_button = None
emoji_button = None
file_button = None
file_info = [None, None, 0, 0]
emoji_info = ''
emoji_list = [[]]
emoji_index = 0


def chat_screen(event, user, message, window, view_frame, input_frame):
    global send_button
    global emoji_button
    global file_button
    view_frame.grid_forget()
    input_frame.grid_forget()
    Grid.rowconfigure(window, 0, weight=4)
    Grid.rowconfigure(window, 1, weight=0)

    view_frame = Frame(window)
    input_frame = Frame(window)
    view_frame.grid(row=0, column=0, sticky=N+E+S+W)
    input_frame.grid(row=1, column=0, sticky=N+E+S+W)

    scroll = Scrollbar(view_frame)
    canvas = Canvas(view_frame, bg='lightblue', yscrollcommand=scroll.set)
    canvas.pack(side=LEFT, fill=BOTH, expand=True)

    canvas_frame = Frame(canvas, bg='lightblue')
    canvas_frame.columnconfigure(0, weight=1)
    canvas_window = canvas.create_window((0, 0), anchor=NW, window=canvas_frame)

    scroll.config(command=canvas.yview)
    scroll.pack(side=RIGHT, fill=Y)

    canvas.bind('<Configure>', lambda event, arg1=canvas, arg2=canvas_window: config_canvas(event, arg1, arg2))

    chat_intro = Text(canvas_frame, width=30, height=len(message)/30, bg='royal blue')
    chat_intro.insert(INSERT, message)
    chat_intro.grid(row=0, column=0, sticky=N)

    input_frame.columnconfigure(1, weight=1)

    input_box = Text(input_frame, width=50, height=1)
    input_box.grid(row=0, column=1, rowspan=2, columnspan=5, sticky=N + E + S + W)

    view_info = [window, input_frame, canvas, canvas_frame, input_box, 1, 1, E]

    send_button = Button(input_frame, text='Send', width=7, height=2, command=lambda event=0, arg1=user, arg2=view_info: send_message(event, arg1, arg2))
    send_button.grid(row=0, column=6, sticky=E)
    input_box.bind('<Return>', lambda event, arg1=user, arg2=view_info: send_message(event, arg1, arg2))
    input_box.bind('<KeyRelease-Return>', lambda event, arg=input_box: clear_input(event, arg))

    emoji_photo = PhotoImage(file=Path(r'emojis/2.png')).subsample(10, 10)
    emoji_button = Button(input_frame, image=emoji_photo, width=55, height=35, command=lambda event=0, arg1=user, arg2=view_info: emoji_menu(event, arg1, arg2))
    emoji_button.grid(row=0, column=0, sticky=W)

    file_photo = PhotoImage(file=Path(r'emojis/paperclip.png')).subsample(35, 35)
    file_button = Button(input_frame, image=file_photo, width=55, height=35, command=lambda event=0, arg1=user, arg2=view_info: file_transfer_menu(event, arg1, arg2))
    file_button.grid(row=1, column=0, sticky=W)

    atexit.register(exit_chat, user)
    window.bind(recv_event, lambda event, arg=view_info: process_recv_event(event, arg))
    Thread(target=recv_message_mode, args=[window, user, view_info], daemon=True).start()

    window.mainloop()


def welcome_screen(window=None, view_frame=None, input_frame=None):
    if window is not None and view_frame is not None and input_frame is not None:
        view_frame.grid_forget()
        input_frame.grid_forget()
    else:
        window = Tk()
        window.title('UDP Chat')
        Grid.rowconfigure(window, 0, weight=2)
        Grid.rowconfigure(window, 1, weight=1)
        Grid.columnconfigure(window, 0, weight=1)
        window.geometry('500x500')

    view_frame = Frame(window)
    view_frame.grid(row=0, column=0, sticky=N+E+S+W)
    title_text = Message(view_frame, text='UDP Chat', font=('fixedsys', 18, 'bold'))
    title_text.pack(fill=BOTH, expand=True)

    input_frame = Frame(window)
    input_frame.grid(row=1, column=0, sticky=N+E+S+W)
    log_button = Button(input_frame, font=('fixedsys', 12), text='chat log', width=7, height=2, command=lambda arg1=window, arg2=view_frame, arg3=input_frame: log_screen(arg1, arg2, arg3))
    log_button.pack(side=LEFT, expand=True)
    chat_button = Button(input_frame, font=('fixedsys', 12), text='chat', width=7, height=2, command=lambda arg1=window, arg2=view_frame, arg3=input_frame: setup_screen(arg1, arg2, arg3))
    chat_button.pack(side=RIGHT, expand=True)

    window.mainloop()


def log_screen(window, view_frame, input_frame):
    view_frame.grid_forget()
    input_frame.grid_forget()
    Grid.rowconfigure(window, 0, weight=4)
    Grid.rowconfigure(window, 1, weight=1)
    view_frame = Frame(window)

    scroll = Scrollbar(view_frame)

    canvas = Canvas(view_frame, yscrollcommand=scroll.set)
    canvas.pack(side=LEFT, fill=BOTH, expand=True)

    canvas_frame = Frame(canvas, bg='cyan')
    canvas_frame.columnconfigure(0, weight=1)
    canvas_window = canvas.create_window((0, 0), anchor=NW, window=canvas_frame)
    scroll.pack(side=RIGHT, fill=Y)
    scroll.config(command=canvas.yview)

    canvas.bind('<Configure>', lambda event, arg1=canvas, arg2=canvas_window: config_canvas(event, arg1, arg2))

    input_frame = Frame(window)

    back_button = Button(input_frame, font=('fixedsys', 12), text='back', width=7, height=2, command=lambda arg1=window, arg2=view_frame, arg3=input_frame: welcome_screen(arg1, arg2, arg3))
    back_button.pack(expand=True)

    try:
        with open('chat_log.txt', 'r') as chat_log:
            i = 0
            for line in chat_log:
                if line[0: 5] == '-----':
                    chat_intro = Text(canvas_frame, width=50, height=len(line) / 50, bg='cyan', font=('fixedsys', 9))
                    chat_intro.insert(INSERT, line)
                    chat_intro.grid(row=i, column=0, sticky=N, columnspan=2)
                elif line[0: 6] == '[user]':
                    mess_display = Text(canvas_frame, width=30, height=len(line) / 30, bg='magenta3', font=('fixedsys', 9))
                    mess_display.insert(INSERT, line[6:])
                    mess_display.grid(row=i, column=1, sticky=E)
                else:
                    mess_display = Text(canvas_frame, width=30, height=len(line) / 30, bg='magenta3', font=('fixedsys', 9))
                    mess_display.insert(INSERT, line)
                    mess_display.grid(row=i, column=0, sticky=W)
                i += 1
    except FileNotFoundError:
        Message(canvas_frame, bg='plum4', text='No previous chat log found.', font=('fixedsys', 18)).pack(expand=True)

    canvas_frame.update_idletasks()
    bbox = canvas.bbox(ALL)
    canvas.configure(scrollregion=bbox)

    view_frame.grid(row=0, column=0, sticky=N + E + S + W)
    input_frame.grid(row=1, column=0, sticky=N + E + S + W)
    window.mainloop()


def setup_screen(window, view_frame, input_frame):
    view_frame.grid_forget()
    input_frame.grid_forget()
    Grid.rowconfigure(window, 0, weight=2)
    Grid.rowconfigure(window, 1, weight=1)
    view_frame = Frame(window)
    Message(view_frame, text='Do you wish to start or join a chatroom?', font=('fixedsys', 18), justify='center').pack(fill=BOTH, expand=True)

    input_frame = Frame(window)
    start_button = Button(input_frame, font=('fixedsys', 12), text='start', width=7, height=2, command=lambda arg1=window, arg2=view_frame, arg3=input_frame: server_creation(arg1, arg2, arg3))
    start_button.pack(side=LEFT, expand=True)
    join_button = Button(input_frame, font=('fixedsys', 12), text='join', width=7, height=2, command=lambda arg1=window, arg2=view_frame, arg3=input_frame: setup_screen_ip(arg1, arg2, arg3))
    join_button.pack(side=RIGHT, expand=True)

    view_frame.grid(row=0, column=0, sticky=N+E+S+W)
    input_frame.grid(row=1, column=0, sticky=N+E+S+W)
    window.mainloop()


def setup_screen_ip(window, view_frame, input_frame):
    view_frame.grid_forget()
    input_frame.grid_forget()
    Grid.rowconfigure(window, 0, weight=1)
    Grid.rowconfigure(window, 1, weight=2)
    view_frame = Frame(window)
    Message(view_frame, text='Enter the IP address or hostname of the device you wish to chat with.', font=('fixedsys', 18), justify='center').pack(expand=True)

    input_frame = Frame(window)

    error_message = Message(input_frame, fg=view_frame.cget('bg'), text='Invalid response', font=('fixedsys', 16), justify='center')
    error_message.pack(side=TOP, expand=True)

    input_box = Entry(input_frame)
    input_box.pack(expand=True)

    event = 0
    enter_button = Button(input_frame, font=('fixedsys', 12), text='enter', width=7, height=2, command=lambda arg0=event,
        arg1=window, arg2=view_frame, arg3=input_frame, arg4=input_box, arg5=error_message: check_ip(arg0, arg1, arg2, arg3, arg4, arg5))
    enter_button.pack(expand=True)

    input_box.bind('<Return>', lambda arg0=event, arg1=window, arg2=view_frame, arg3=input_frame, arg4=input_box,
                                      arg5=error_message: check_ip(arg0, arg1, arg2, arg3, arg4, arg5))

    view_frame.grid(row=0, column=0, sticky=N + E + S + W)
    input_frame.grid(row=1, column=0, sticky=N + E + S + W)
    window.mainloop()


def check_ip(event, window, view_frame, input_frame, input_box, error_message):
    # Prompt user for server address
    address = input_box.get()
    invalid = False
    if address.__len__() < 7 or address.__len__() > 15:
        if error_message.cget('fg') == view_frame.cget('bg'):
            error_message.config(fg='black')

    for i in range(0, address.__len__()):
        if address[i] != 0 or address[i] != 1 or address[i] != 2 or address[i] != 3 or address[i] != 4 or address[i] != 5 \
                or address[i] != 6 or address[i] != 7 or address[i] != 8 or address[i] != 9 or address[i] != '.':
            if error_message.cget('fg') == view_frame.cget('bg'):
                error_message.config(fg='black')

    dot_1 = address.find('.')
    if dot_1 > 0:
        sub_address = address[dot_1 + 1: address.__len__()]
        dot_2 = sub_address.find('.')
        if dot_2 > 0:
            sub_address = sub_address[dot_2 + 1: sub_address.__len__()]
            dot_3 = sub_address.find('.')
            if dot_3 > 0:
                client_creation(event, window, view_frame, input_frame, address)
            else:
                invalid = True
        else:
            invalid = True
    else:
        invalid = True

    if invalid:
        if error_message.cget('fg') == view_frame.cget('bg'):
            error_message.config(fg='black')

def emoji_menu(event, user, view_info):
    window, input_frame, canvas, canvas_frame, input_box, row, column, sticky = view_info[0], view_info[1], view_info[
        2], view_info[3], view_info[4], view_info[5], view_info[6], view_info[7]
    input_text = input_box.get('1.0', 'end-1c')
    input_box.config(fg='SystemButtonFace', bg='SystemButtonFace')

    for i in range(0, 12):
        input_frame.columnconfigure(i, weight=1)

    button_list = []
    photo_list = []

    for i in range(0, 5):
        photo_list.append(PhotoImage(file=Path(r'emojis/'+str(i)+'.png')).subsample(10, 10))
        button_list.append(Button(input_frame, width=55, height=35, image=photo_list[i], command=lambda event=0, arg1=user, arg2=view_info, arg3=input_text, arg4=i,
                                                 arg5=button_list: text_transfer_menu(event, arg1, arg2, arg3, arg4, arg5)))
        button_list[i].grid(row=0, column=i + 1)
    for i in range(5, 10):
        photo_list.append(PhotoImage(file=Path(r'emojis/'+str(i)+'.png')).subsample(10, 10))
        button_list.append(Button(input_frame, width=55, height=35, image=photo_list[i], command=lambda event=0, arg1=user, arg2=view_info, arg3=input_text, arg4=i,
                                                 arg5=button_list: text_transfer_menu(event, arg1, arg2, arg3, arg4, arg5)))
        button_list[i].grid(row=1, column=i + 1 - 5)

    emoji_button.bind('<Button-1>', lambda event=0, arg1=user, arg2=view_info, arg3=input_text, arg4=10,
                                                 arg5=button_list: text_transfer_menu(event, arg1, arg2, arg3, arg4, arg5))
    window.mainloop()


def file_transfer_menu(event, user, view_info):
    window, input_frame, canvas, canvas_frame, input_box, row, column, sticky = view_info[0], view_info[1], view_info[
        2], view_info[3], view_info[4], view_info[5], view_info[6], view_info[7]
    input_text = input_box.get('1.0', 'end-1c')
    input_box.delete('1.0', END)
    input_box.config(bg='gray')
    input_box.insert('insert', 'Enter the file path for a file to transfer.')
    input_box.bind('<Button-1>', lambda event, arg=input_box: clear_input(event, arg))
    input_box.bind('<Return>', lambda event, arg1=user, arg2=view_info, arg3=input_text: text_transfer_menu(event, arg1, arg2, arg3))
    send_button.bind('<Button-1>', lambda event, arg1=user, arg2=view_info, arg3=input_text: text_transfer_menu(event, arg1, arg2, arg3))
    file_button.bind('<Button-1>', lambda event, arg1=user, arg2=view_info, arg3=input_text: text_transfer_menu(event, arg1, arg2, arg3))
    window.mainloop()


# Function to respond to input from a special input_frame mode (emoji, file transfer, image) and return to standard text input mode
def text_transfer_menu(event, user, view_info, input_text, index=None, button_list=None):
    global send_button
    global emoji_info
    window, input_frame, canvas, canvas_frame, input_box, row, column, sticky = view_info[0], view_info[1], view_info[
        2], view_info[3], view_info[4], view_info[5], view_info[6], view_info[7]

    # Use of the function without a user indicates the call originated from emoji_menu and therefore must react to an emoji button press
    if index is not None and button_list is not None:
        index = index
        if index == 10:
            pass
        else:
            emoji_code = '{' + str(index) + '}'
            count = str(input_box.count('1.0', END))
            count = count[1: count.__len__()-2]
            emoji_photo = PhotoImage(file=Path(r'emojis/'+str(index)+'.png')).subsample(15, 15)
            input_box.image_create(image=emoji_photo, index=END)
            emoji_info = emoji_info + emoji_code + count
        for i in range(0, 12):
            if i == 1:
                input_frame.columnconfigure(i, weight=1)
            else:
                input_frame.columnconfigure(i, weight=0)
            if i in range(0, 10):
                button_list[i].grid_forget()
        input_box.config(bg='SystemWindow', fg='SystemWindowText')
        emoji_button.bind('<Button-1>', lambda event=0, arg1=user, arg2=view_info: emoji_menu(event, arg1, arg2))

    # When a user is given, the call originated from file_transfer and the function must therefore initiate file transfer
    else:
        file_path = r'' + input_box.get('1.0', 'end-1c')
        if file_path == '':
            input_box.delete('1.0', END)
            input_box.config(bg='SystemWindow')
            input_box.insert('insert', input_text)
            input_box.unbind('<Button-1>')
            input_box.bind('<Return>', lambda event, arg1=user, arg2=view_info: send_message(event, arg1, arg2))
            send_button.bind('<Button-1>', lambda event, arg1=user, arg2=view_info: send_message(event, arg1, arg2))
            file_button.bind('<Button-1>', lambda event, arg1=user, arg2=view_info: file_transfer_menu(event, arg1, arg2))
        else:

            # Determining file size while checking if file can be found
            found = None
            try:
                file_size = os.stat(file_path).st_size
                found = True
            except FileNotFoundError:
                found = False

            if found:
                # Gather filepath for transfer and determines file name by filtering out slashes in path
                file_name = file_path
                name_check = ''
                if file_name.find('\\') > -1:
                    while name_check != file_name:
                        name_check = file_name
                        file_name = file_name[file_name.find('\\') + 1: file_name.__len__()]
                elif file_name.find('/') > -1:
                    while name_check != file_name:
                        name_check = file_name
                        file_name = file_name[file_name.find('/') + 1: file_name.__len__()]

                file_info[1] = file_name
                file_info[3] = file_size
                # Establishing path, name, data currently sent (and received), and total data size for the file being sent.
                Thread(target=user.file_transfer, args=[file_path, file_name, file_size], daemon=True).start()
                input_box.delete('1.0', END)
                input_box.config(bg='SystemWindow')
                input_box.insert('insert', input_text)
                input_box.unbind('<Button-1>')
                input_box.bind('<Return>', lambda event, arg1=user, arg2=view_info: send_message(event, arg1, arg2))
                send_button.bind('<Button-1>', lambda event, arg1=user, arg2=view_info: send_message(event, arg1, arg2))
                file_button.bind('<Button-1>', lambda event, arg1=user, arg2=view_info: file_transfer_menu(event, arg1, arg2))
            else:
                input_box.delete('1.0', END)
                input_box.insert('insert', 'File not found')
    window.mainloop()


# Function to update chat by main thread for messages received by the child thread (Since Tkinter does not allow multiple threads to update the same Tk object)
def process_recv_event(event, view_info):
    global block_event
    while recv_message_queue.empty() is False:
        queue_message = recv_message_queue.get(block=False)
        message = queue_message[0]
        user = queue_message[1]
        if queue_message.__len__() == 2:
            update_chat(user, message, view_info)
        elif queue_message.__len__() == 3:
            address_file_flag = queue_message[2]
            update_chat(user, message, view_info, address_file_flag)
        elif queue_message.__len__() == 4:
            file_flag = queue_message[2]
            seq_dif = queue_message[3]
            update_chat(user, message, view_info, file_flag, seq_dif)
        elif queue_message.__len__() == 5:
            file_flag = queue_message[2]
            file_name = queue_message[3]
            file_size = queue_message[4]
            update_chat(user, message, view_info, file_flag, file_name, file_size)
    block_event = False


def recv_message_mode(window, user, view_info):
    global block_event
    global file_info
    while True:
        got_header, got_message, got_address_port, owner, seq_dif = user.recv()
        if not (isinstance(got_message, bool)):
            file_name = None
            file_size = None
            file_inf = file_info[1]

            # Detection of standard message
            if got_header[1] is None and got_header[2] == 0 and got_header[3] == 0 and got_header[4] == 0:
                    user.update_history(owner, got_message)

            # Detection of file transfer
            elif got_header[4] > 0:
                if got_header[4] == 1:
                    file_name = got_message[1: got_message.find(',')]
                    file_size = int(got_message[got_message.find(',') + 1: got_message.find(']')])
                    file = open(file_name, 'w+')
                    file.close()
                    file_info[1], file_info[2], file_info[3] = file_name, 0, file_size
                    user.update_history(owner, '', 1, file_name)
                elif got_header[4] == 2 or got_header[4] == 3:
                    if got_header[5]:
                        with open(file_info[1], 'a+') as file:
                            file.write(got_message)
                    elif not got_header[5]:
                        with open(file_info[1], 'ab+') as file:

                            # Convert sent message string into a tuple to be converted into binary for writing
                            data_tuple = got_message
                            data_tuple = data_tuple[1:-1]
                            data_tuple = data_tuple.split(",")
                            data_tuple = [int(x) for x in data_tuple]
                            data_tuple = tuple(data_tuple)
                            file.write(pack('hh1' + data_tuple))
                    if got_header[4] == 3:
                        user.update_history(owner, '', 3, file_info[1])

            # Send an ACK when the received ACK field is empty and it is not an exit message (and is therefore a message needing acknowledgement)
            if got_header[0] is not None and got_header[1] is None and got_header[3] != 1:

                if got_header[4] > 0:
                    if got_header[4] == 1:
                        header = [None, got_header[0] + 1, 0, 0, -1, None]
                    elif got_header[4] == 2:
                        header = [None, got_header[0] + 1, 0, 0, -2, None]
                    elif got_header[4] == 3:
                        header = [None, got_header[0] + 1, 0, 0, -3, None]
                else:
                    header = [None, got_header[0] + 1, 0, 0, 0, None]
                send_message = ''
                user.send(header, send_message)

                # Add received message to canvas for chat display when not an ACK and not an exit message
                view_info[6] = 0
                view_info[7] = W
                if got_header[4] == 0:
                    queue_message = [got_message, user]
                    recv_message_queue.put(queue_message)
                elif got_header[4] == 1:
                    queue_message = [got_message, user, got_header[4], file_name, file_size]
                    recv_message_queue.put(queue_message)
                elif got_header[4] == 2:
                    queue_message = [got_message, user, got_header[4], seq_dif]
                    recv_message_queue.put(queue_message)
                elif got_header[4] == 3:
                    queue_message = [got_message, user, got_header[4]]
                    recv_message_queue.put(queue_message)

            # Messages here are displayed by putting message info in queue for main thread to call update_chat

            # Update the display for a sent file transfer message based on the receival of an ACK for a piece of the file
            elif got_header[0] is None and got_header[1] is not None and got_header[4] < 0:
                queue_message = [got_message, user, got_header[4], seq_dif]
                recv_message_queue.put(queue_message)

            # Add special message to canvas denoting a user leaving when an exit message is received
            elif got_header[3] == 1:
                queue_message = ['', user, got_address_port[0]]
                recv_message_queue.put(queue_message)

            if not block_event:
                block_event = True
                window.event_generate('<<recv>>', when='tail')



def send_message(event, user, view_info):
    global emoji_info
    window, input_frame, canvas, canvas_frame, input_box, row, column, sticky = view_info[0], view_info[1], view_info[2], view_info[3], view_info[4], view_info[5], view_info[6], view_info[7]
    header = [user.seq, None, 0, 0, 0, None]
    message = view_info[4].get('1.0', 'end-1c') + emoji_info
    input_box.delete('1.0', END)
    # Stops user from sending an empty message
    if message != '':
        view_info[6], view_info[7] = 1, E
        emoji_info = ''
        user.send(header, message)
        user.update_history(user, message)
        update_chat(user, message, view_info)


# Function to analyze parameters given to determine type of message and perform the necessary operations for display
def update_chat(user, message, view_info, leave_file_flag=None, dif_file_name=None, file_size=None):
    global send_button
    global file_info
    global emoji_list
    global emoji_index
    e_i = emoji_index
    window, input_frame, canvas, canvas_frame, input_box, row, column, sticky = view_info[0], view_info[1], view_info[2], view_info[3], view_info[4], view_info[5], view_info[6], view_info[7]
    # With no file_flag or exit code, a normal message is displayed with emoji functionality
    if leave_file_flag is None:
        mess_display = Text(canvas_frame, width=20, height=len(message) / 20, bg='magenta3', font=('Ariel', 9))
        if message.find('{') > -1 and message.find('}') == message.find('{') + 2:
            emoji_list.append([])
            full_message = message
            text_message = message[0: message.find('{')]
            emoji_code_index = full_message.find('{')
            scrap = full_message[emoji_code_index:]
            i = 0
            while emoji_code_index > -1:
                if scrap[1] == str(0) or scrap[1] == str(1) or scrap[1] == str(2) or \
                        scrap[1] == str(3) or scrap[1] == str(4) or scrap[1] == str(5) or \
                        scrap[1] == str(6) or scrap[1] == str(7) or scrap[1] == str(8) or scrap[1] == str(9):
                    emoji_num = scrap[1]
                    scrap = scrap[3:]
                    if scrap.find('{') > -1:
                        emoji_count = scrap[0: scrap.find('{')]
                        scrap = scrap[scrap.find('{'):]
                    else:
                        emoji_count = scrap
                    emoji_list[e_i].append([])
                    emoji_list[e_i][i].append(PhotoImage(file=Path(r'emojis/' + str(emoji_num) + '.png')).subsample(15, 15))
                    emoji_list[e_i][i].append(int(emoji_count))
                    emoji_code_index = scrap.find('{')
                    i += 1
                else:
                    break
            message_parts = []

            if text_message != '':
                message_parts.append(text_message[0: emoji_list[e_i][0][1]-1])
                for j in range(0, emoji_list[e_i].__len__()-1):
                    message_parts.append(text_message[emoji_list[e_i][j][1]: emoji_list[e_i][j+1][1]-1])
                message_parts.append(text_message[emoji_list[e_i][emoji_list[e_i].__len__()-1][1]:])

                message_parts_copy = message_parts
                emoji_list_copy = emoji_list

                k = 0
                for i in range(0, message_parts.__len__()):
                    mess_display.insert(INSERT, message_parts_copy[i])
                    if i < emoji_list[e_i].__len__():
                        mess_display.image_create(INSERT, image=emoji_list_copy[e_i][i][0])
                    k = i

                if emoji_list[e_i].__len__() > message_parts.__len__():
                    while k < emoji_list[e_i].__len__():
                        mess_display.image_create(INSERT, image=emoji_list_copy[e_i][k][0])
                        k += 1
            else:
                for i in range(0, emoji_list[e_i].__len__()):
                    mess_display.image_create(INSERT, image=emoji_list[e_i][i][0])

        else:
            mess_display.insert(INSERT, message)

        mess_display.grid(row=row, column=column, sticky=sticky)
        row += 1
        view_info[5] = row
        set_scrollregion(canvas, canvas_frame)

    # The presence of a string for a flag indicates a user leaving and therefore should give a special message
    elif isinstance(leave_file_flag, str):
        leave = leave_file_flag
        mess_display = Text(canvas_frame, width=20, height=len(message) / 20, bg='royal blue', font=('Ariel', 9))
        mess_display.insert(INSERT, leave + ' has left the chat.')
        mess_display.grid(row=row, column=0, sticky=N)
        row += 1
        view_info[5] = row
        set_scrollregion(canvas, canvas_frame)
    # An int for a flag indicates file transfer. Different actions are taken for each sector of file transfer.
    elif isinstance(leave_file_flag, int):
        file_flag = leave_file_flag
        if file_flag == 1:
            file_name = dif_file_name
            mess_display = Text(canvas_frame, width=20, height=2, bg='magenta3', font=('Ariel', 9))
            mess_display.insert(INSERT, 'Downloading file: ' + file_name + '\n|                    |')
            mess_display.grid(row=row, column=column, sticky=sticky)
            row += 1
            view_info[5] = row
            file_info[0] = mess_display
        elif file_flag == -1:
            mess_display = Text(canvas_frame, width=20, height=2, bg='magenta3', font=('Ariel', 9))
            mess_display.insert(INSERT, 'Sending file: ' + file_info[1] + '\n|                    |')
            mess_display.grid(row=row, column=column, sticky=sticky)
            row += 1
            view_info[5] = row
            file_info[0] = mess_display
        elif file_flag == 2 or file_flag == -2:
            dif = dif_file_name
            file_info[2] = file_info[2] + (1024 * dif)
            bar = '|'
            progress = file_info[2] / file_info[3]
            progress = int(progress / 0.04)
            for i in range(0, progress):
                bar = bar + '-'
            for i in range(progress, 25):
                bar = bar + ' '
            bar = bar + '|'
            if file_flag == 2:
                file_info[0].delete('1.0', END)
                file_info[0].insert(END, 'Downloading file: ' + file_info[1] + '\n' + bar)
            elif file_flag == -2:
                file_info[0].delete('1.0', END)
                file_info[0].insert(END, 'Sending file: ' + file_info[1] + '\n' + bar)
        elif file_flag == 3:
            file_info[0].delete('1.0', END)
            file_info[0].insert(END, 'File downloaded: ' + file_info[1])
        elif file_flag == -3:
            file_info[0].delete('1.0', END)
            file_info[0].insert(END, 'File sent: ' + file_info[1])
    emoji_index += 1
    emoji_list.append([])
    window.update()


def write_log(self):
    # Upon exiting application, a .txt file is created / added to for the storing of chat data this session. The
    # system is set up to show the time and list of users on chat session start with separations before and after
    # all data for a session so that multiple sessions can be separately stored in one file.
    with open('chat_log.txt', 'a+') as chat_log:
        chat_log.write('-----Chat Log for {}/{}/{} at {}:{}-----\n'.format(self.chat_log_time.month, self.chat_log_time.day, self.chat_log_time.year, self.chat_log_time.hour, self.chat_log_time.minute))
        chat_log.write('---------' + self.chat_log_users + '----------\n')
        for i in range(0, self.history.__len__()):
            if self.history[i] == '':
                for j in range(0, self.others.__len__()):
                    if self.others[j].history[i] != '':
                        chat_log.write(self.others[j].history[i]+'\n')
            else:
                chat_log.write('[user]'+self.history[i]+'\n')
        chat_log.write('-----End of Chat-----\n')


def server_creation(window, view_frame, input_frame):
    user = Device.Device()
    message = user.server_handshake()
    event=0
    chat_screen(event, user, message, window, view_frame, input_frame)


def client_creation(event, window, view_frame, input_frame, address):
    user = Device.Device()
    message = user.client_handshake(address)
    chat_screen(event, user, message, window, view_frame, input_frame)


def set_scrollregion(canvas, canvas_frame):
    canvas_frame.update_idletasks()
    bbox = canvas.bbox(ALL)
    canvas.configure(scrollregion=bbox)
    canvas.yview_moveto(1)


def config_canvas(event, canvas, canvas_window):
    canvas.itemconfig(canvas_window, width=event.width)


def clear_input(event, input_box):
    input_box.delete('1.0', END)


def exit_chat(user):
    write_log(user)


if __name__ == '__main__':
    welcome_screen()
